.pragma library

// these are the keys for the Instagram client
// get them here: http://instagram.com/developer/clients/manage/
// (you need to be logged into Instagram to create apps)
var instagramClientId = "3bbd61a332384e66a46026c3dbbfaadc"; // Instagram client id
var instagramClientSecret = ""; // Instagram client secret
