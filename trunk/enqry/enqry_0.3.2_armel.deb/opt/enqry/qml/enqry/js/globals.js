.pragma library
var imagePath = ""
var loadCounter = 0
var imageProcessed = 0;
