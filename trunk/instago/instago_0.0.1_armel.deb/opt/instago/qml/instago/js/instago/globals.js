.pragma library

var currentGalleryContent = [];
var currentGalleryIndex = 0;
